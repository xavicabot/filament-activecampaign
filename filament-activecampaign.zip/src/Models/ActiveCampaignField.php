<?php

namespace XaviCabot\FilamentActiveCampaign\Models;

use Illuminate\Database\Eloquent\Model;

class ActiveCampaignField extends Model
{
    protected $table = 'activecampaign_fields';

    protected $guarded = [];
}
