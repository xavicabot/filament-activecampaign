<?php

namespace XaviCabot\FilamentActiveCampaign\Models;

use Illuminate\Database\Eloquent\Model;

class ActiveCampaignList extends Model
{
    protected $table = 'activecampaign_lists';

    protected $guarded = [];
}
