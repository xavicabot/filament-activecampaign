<?php

namespace XaviCabot\FilamentActiveCampaign\Models;

use Illuminate\Database\Eloquent\Model;

class ActiveCampaignTag extends Model
{
    protected $table = 'activecampaign_tags';

    protected $guarded = [];
}
